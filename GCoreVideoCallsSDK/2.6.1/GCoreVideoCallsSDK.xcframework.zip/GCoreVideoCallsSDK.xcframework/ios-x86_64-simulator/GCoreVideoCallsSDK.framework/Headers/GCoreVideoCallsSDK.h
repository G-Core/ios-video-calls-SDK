#import <Foundation/Foundation.h>

//! Project version number for GCoreLabMeetSDK.
FOUNDATION_EXPORT double GCoreLabMeetSDKVersionNumber;

//! Project version string for GCoreLabMeetSDK.
FOUNDATION_EXPORT const unsigned char GCoreLabMeetSDKVersionString[];
#import <mediasoup_client_ios/Mediasoupclient.h>
